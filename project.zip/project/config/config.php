<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "db_blog");
define("TITLE", "Training with live project");
define("KEYWORDS", "PHP Tutorial, JAVA Tutorial, Oracle Database");
